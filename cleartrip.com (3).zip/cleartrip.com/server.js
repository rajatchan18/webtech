var express=require("express");
var bp=require("body-parser");
var mongo = require("mongojs");

var db = mongo("cleartrip",["alabama_kansas","alaska_ohio"]);

var app=express();
	app.use(express.static(__dirname));
	app.use(bp.json());
	
app.get("/",function(req,res){
	res.send();
});

app.get("/alabama_kansas",function(req,res){
 db.alabama_kansas.find(function(e,docs){
  console.log(docs);
  res.json(docs);
 });
});
app.get("/alaska_ohio",function(req,res){
 db.alaska_ohio.find(function(e,docs){
  console.log(docs);
  res.json(docs);
 });
});

app.listen(8888);
console.log("server is running on 8888");
