(function(){	
angular.module("app",["ui.bootstrap","ngRoute","ngMessages",]);
}())