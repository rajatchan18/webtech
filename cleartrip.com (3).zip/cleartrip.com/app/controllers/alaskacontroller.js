 (function(){	
angular.module("app")
.controller("alaskacontroller",flightfunc);
function flightfunc($scope,$routeParams,$http){
	$scope.param=$routeParams.city;
	$scope.resultone = null;
 $http.get("/alaska_ohio")
	 .success(function(r,s,x){
	 	$scope.resultone = r;
	 })
	 .error(function(e,s,x){
	 	console.log(error);
	 })
}
})()
