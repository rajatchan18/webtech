(function(){	
angular.module("app")
.controller("anothercontroller",flightfun);
function flightfun($scope,$routeParams,$http){
	$scope.param=$routeParams.city;
	$scope.result = null;
	 
	 $http.get("/alabama_kansas")
	 .success(function(r,s,x){
	 	console.log(r);
	 	$scope.result = r;
	 })
	 .error(function(e,s,x){
	 	console.log("error");
	 });
	
	 
}

}())			