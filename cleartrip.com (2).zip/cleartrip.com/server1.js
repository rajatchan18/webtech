var express=require("express");
var bp=require("body-parser");
 var mongo = require("mongojs");

var db = mongo("cleartrip",["alabama_kansas"]);
var app=express();
	app.use(express.static(__dirname));
	app.use(bp.json());
	
app.get("/",function(req,res){
	res.send();
});

app.get("/alabama_kansas",function(req,res){
	db.alabama_kansas.find(function(e,docs){
		console.log(docs);
		console.log(e);
		res.json(docs);
	});
	});
app.listen(1111);
console.log("server running on port 8888"); 
