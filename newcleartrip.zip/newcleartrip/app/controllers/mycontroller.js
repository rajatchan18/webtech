(function(){
	
angular.module('flightModule', [])
.controller('flightController',function($scope){
	
	// give a meaningfull controller name not my or your controller
	// Every new module has a name and a controller attached to it.
	// you can attach more components to it. Use a separate js file for it.
	//For eg a directive
	
	
	
					console.log("flightController loaded");
					
					
					
					
					
			}).directive('dummyDirective',function(){
				
				// how to inject it IF you write like this then is auto injected
				// if you are creating a separate js then include its module nam in the array defined in module as directive name as dependency to //flightController
					
				console.log('dummyDirective');
				
			}).filter('dummyFilter',function(){
				
				console.log('dummyFilterm');
				
			})
})();