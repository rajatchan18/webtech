(function() {
  'use strict';

  angular.module('app', ['routeVariable','flightModule'])
    .controller("AppController",function($rootScope,$scope,$state){
		
		// this is your main controller using routeVariable as depenedncy  for routing and child controller flightModule as your new controller
		// So if you want to add anything common across all part of your application then you needed to inject it here.
		// For example  we used routing , you can have a directive that can be used accross all modules.
		

     console.log("AppController controller Loaded")
	 // this tell router to go to which page viz. Login page. check in config file  and for their it will take controller
		 $state.go("login");
	  
	})
})();