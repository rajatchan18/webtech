(function() {
  'use strict';
  angular
    .module('routing', ['ui.router'])
    .config(routeConfig);

  /** @ngInject */
  function routeConfig($stateProvider, $urlRouterProvider) {
    $stateProvider.state('login', {
        url: '/login',
        templateUrl: 'app/views/flightpage.html',
        controller: 'flightController',
        controllerAs: 'flight'
      })}

})();
