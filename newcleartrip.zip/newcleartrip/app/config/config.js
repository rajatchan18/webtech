(function() {
  'use strict';
  angular.module('routeVariable', ['ui.router'])
    .config(routeConfig);
// routeVariable is a module that is needed to be injected in your main Controller that is AppController as is using ui-router as dependency
  /** @ngInject */
  function routeConfig($stateProvider, $urlRouterProvider) {
    $stateProvider
    
    
    
    .state('login', {
        url: '/login',
        templateUrl: 'app/views/flightpage.html',
        controller: 'flightController',
        controllerAs: 'flight'
      })
      
      .state('page1', {
        url: '/page1',
        templateUrl: 'app/views/page1.html',
        controller: 'flightController',
        controllerAs: 'flight'
      })
      .state('page2', {// state
        url: '/page2',//url
        templateUrl: 'app/views/page2.html',// html file name you want to show	
        controller: 'flightController',// controller name
        controllerAs: 'flight'// controller alias name
      })
	  
	  
	  
	  }

})();
