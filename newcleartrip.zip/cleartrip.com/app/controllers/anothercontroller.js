(function(){
	
angular.module("app").controller("anothercontroller",flightfun);
function flightfun($scope,$routeParams,$http){
	$scope.param=$routeParams.flights;
	$scope.result = null;
	 
	 $scope.flights=[
	 {
	 	
	  "id":1,
	  "flightroute":"Alabama"
	 }
	 ]
	 
	 $http.get("/alabama_kansas")
	 .success(function(r,s,x){
	 	console.log(r);
	 	$scope.result = r;
	 })
	 .error(function(e,s,x){
	 	console.log("error");
	 });
}

}())			