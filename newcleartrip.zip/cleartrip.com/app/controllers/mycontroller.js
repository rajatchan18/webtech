(function(){
	
angular.module("app")
.controller("mycontroller",function($scope,$location){
			//$scope.flights=""
			$scope.go = function ( path ) {
				if($scope.from_airport!=null && $scope.to_airport!=null)
  $location.path( path );
};
			
			
			
			$scope.selected = undefined;
            $scope.states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut',
             'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 
             'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 
             'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York', 'North Dakota',
              'North Carolina', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
               'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];
	})
		/*
		$scope.flights=[
		{
             "id" : 1,
             "name":"Fly Emirates",
             "from":"Alabama",
             "to":"Kansas",
             "arrival":"5:00 a.m.",
             "departure":"2:00 a.m.",
             "Total time":"3 hrs",
             "photo":"lib/images/general--emirates-plane--620x300.jpg"			
		}
		];
		 */
.factory('modalFactory', function($uibModal) {
    return {
      open: function(size, template, params) {
        return $uibModal.open({
          animation: true,
          templateUrl: template || 'myModalContent.html',
          controller: 'ModalResultInstanceCtrl',
          size: size,
          resolve: {
            params: function() {
              return params;
            }
          }
        });
      }
    };
  })
  .controller('ModalDemoCtrl', function($rootScope, $scope, $log, $uibModal) {

    //$scope.items = ['item1', 'item2', 'item3'];

    //$scope.animationsEnabled = true;

    $scope.open = function(size, template) {
      var modalInstance = $uibModal.open({
          animation: $scope.animationsEnabled,
          templateUrl: template || 'myModalContent.html',
          controller: 'ModalInstanceCtrl',
          size: size
        });

      /*modalInstance.result.then(function(selectedItem) {
        $scope.selected = selectedItem;
      }, function() {
        $log.info('Modal dismissed at: ' + new Date());
      });*/
    };

    $scope.toggleAnimation = function() {
      $scope.animationsEnabled = !$scope.animationsEnabled;
    };

  })

// Please note that $modalInstance represents a modal window (instance) dependency.
// It is not the same as the $uibModal service used above.

.controller('ModalInstanceCtrl', function($scope, $uibModalInstance, modalFactory) {

  //$scope.searchTerm = term;

  $scope.ok = function() {
    modalFactory.open('lg', 'result.html', {searchTerm: $scope.searchTerm});
    
    //$uibModalInstance.close($scope.searchTerm);
  };

  $scope.cancel = function() {
    $uibModalInstance.dismiss('cancel');
  };
})

.controller('ModalResultInstanceCtrl', function($scope, $uibModalInstance, params) {

  $scope.searchTerm = params.searchTerm;

  $scope.ok = function() {
    $uibModalInstance.close($scope.searchTerm);
  };

  $scope.cancel = function() {
    $uibModalInstance.dismiss('cancel');
  };
})
}())