(function(){
	angular.module("app").config(function($routeProvider){
	$routeProvider
	.when("/",{
	    controller : "mycontroller",
	    templateUrl : "app/views/flightpage.html"
	})
	.when("/alabama_kansas",{
		controller :"anothercontroller",
		templateUrl:"app/views/result.html"
	})
	 
	});
}());