var express=require("express");
var app=express();

var bp=require("body-parser");
app.use(bp.json());

var mongo=require("mongojs");
var db=mongo("mtlist",["emp"]);

app.use(express.static(__dirname));

app.get("/",function(req,res){
 res.send();
});

app.get("/emplist",function(req,res){
 db.emp.find(function(e,docs){
  console.log(docs);
  res.json(docs);
 });
});

app.post("/emplist",function(req,res){
 db.emp.insert(req.body,function(e,data){
  console.log(data);
  res.json(data);
 });
});
//the "id" here is a variable with which we can grab the parameters or the query string
app.delete("/emplist/:id",function(req,res){
 var eid=req.params.id;
 console.log("delete request has been requested")
 db.emp.remove({_id:mongo.ObjectId(eid)},function(e,data){
  console.log(data);
  res.json(data);
 });
});
app.put("/emplist/:id",function(res,req){
	var eid=req.param.id;
	db.emp.findAndModify({
		query:{_id:mongo.ObjectId(eid)},
		update:{$set:{
			fname:req.body.fname,
			lname:req.body.fname,
			city:req.body.fname,
			mid:req.body.fname,
			email:req.body.fname,
		}},new:true},function(error,doc){
			res.send(doc)
		})
})
 app.listen(8888);
 console.log("your server is now running on 8888");