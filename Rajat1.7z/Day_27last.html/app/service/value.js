(function(){
	 angular.module("app").value("valueservice","Welcome to india");
}());