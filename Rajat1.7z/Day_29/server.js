var mod = require("./mod");

mod.v;
mod.mf();
