var fs=require("fs");
/*
fs.writeFile("./some.txt","Welcome to your life",function(error,data){
	console.log("line # 4");
})
console.log("line # 6");
*/
console.log("line # 9");
fs.writeFileSync("./some.txt","javascript");
console.log("line # 11");
