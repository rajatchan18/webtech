var val=4444;
function myfun(){
	console.log(val+val)
}

module.exports={
	v:val,
	mf:myfun
}
