(function(){
	function secondControllerFun($scope){
		$scope.message1="";
	}
	angular.module("childapp")
	.controller("secondController",secondControllerFun)
}())