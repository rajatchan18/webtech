(function(){
	function firstControllerFun($scope){
		$scope.message1="well its on";
	}
	angular.module("mainapp")
	.controller("firstController",firstControllerFun)
}())
