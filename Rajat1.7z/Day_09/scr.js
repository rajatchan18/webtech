var s="hello world"//start with some text
s.charAt(0)//"h":the first caracter
s.charAt(s.length-1)//"d":the last character
s.substring(1,4)//"ell":start and until
s.slice(1,4) //same as above
s.slice(-3) //last three
s.indexof("l")//position of first l
s.lastindexof("l")//position of last l
s.indexof("l",3)//position of first l at or after 3
s.split(",") //
